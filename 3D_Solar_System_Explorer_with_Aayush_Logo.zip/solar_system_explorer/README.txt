# 3D Solar System Explorer

A single-page interactive 3D Solar System science project.

## Run
Open `index.html` in a modern browser with an internet connection. The 3D engine (Three.js) is loaded from jsDelivr CDN.

## Publish free
1. Create a GitHub account (with help from a parent/guardian if needed).
2. Create a new public repository named `solar-system-explorer`.
3. Upload `index.html` to the repository root.
4. Open Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch, branch `main`, folder `/ (root)`, then Save.
6. Wait for the Pages URL shown there. It will look like `https://YOUR-USERNAME.github.io/solar-system-explorer/`.

The site is public. Do not put private personal information on it.
